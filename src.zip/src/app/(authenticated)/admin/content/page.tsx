import { getContents } from '@/actions/admin-action'
import RoleGate from '@/components/auth/role-gate'
import { Role } from '@prisma/client'

export default async function Page() {
  return <div>...</div>
}
