export default function Page() {
    return <div>Halaman kosong sementara</div>;
  }
  
