export default async function Page() {
  return (
    <div>
      {/* Konten halaman admin content-create */}
    </div>
  )
}
