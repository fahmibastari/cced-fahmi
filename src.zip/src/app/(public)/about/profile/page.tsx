import ProfileApp from '@/components/about/profile/ProfileApp'

export default function Page() {
  return <ProfileApp />
}
