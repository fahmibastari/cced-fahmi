import Register from '@/components/auth/register/RegisterForm'

export default function Page() {
  return <Register />
}
